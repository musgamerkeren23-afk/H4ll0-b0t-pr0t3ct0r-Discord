# H4ll0 W0rld Discord Bot

Bot Discord buat server H4ll0 W0rld: Moderasi manual, Automod (anti-spam, anti-link, filter kata kasar), dan notifikasi script baru.

## 🚀 Setup

### 1. Buat aplikasi bot di Discord
1. Buka https://discord.com/developers/applications
2. Klik **New Application**, kasih nama (misal `H4ll0 Bot`)
3. Masuk tab **Bot** → klik **Reset Token** → copy token-nya (ini buat `DISCORD_TOKEN`)
4. Di tab **Bot**, nyalain **Server Members Intent** dan **Message Content Intent**
5. Di tab **OAuth2 → URL Generator**, centang scope `bot` dan `applications.commands`, lalu centang permission: Ban Members, Kick Members, Moderate Members, Manage Messages, Send Messages, Read Message History
6. Copy link yang muncul di bawah, buka di browser, invite bot ke server lo

### 2. Ambil ID yang dibutuhkan
- **CLIENT_ID**: tab **General Information** di Discord Developer Portal → copy Application ID
- **GUILD_ID**: nyalain Developer Mode di Discord (Settings → Advanced), klik kanan nama server → Copy Server ID
- **OWNER_ID**: klik kanan nama lo di Discord → Copy User ID
- **LOG_CHANNEL_ID** & **SCRIPT_CHANNEL_ID**: klik kanan channel yang mau dipakai → Copy Channel ID

### 3. Install & jalankan (lokal, buat testing)
```bash
npm install
cp .env.example .env
# isi semua value di .env
npm run deploy   # deploy slash command ke server (sekali aja / tiap ada command baru)
npm start        # jalanin bot
```

## ☁️ Deploy ke Railway (rekomendasi)
1. Push project ini ke GitHub repo baru
2. Buka https://railway.app → New Project → Deploy from GitHub Repo
3. Pilih repo bot lo
4. Di tab **Variables**, masukin semua isi `.env` lo (DISCORD_TOKEN, CLIENT_ID, dst)
5. Di tab **Settings**, set **Start Command**: `npm start`
6. Railway bakal auto-deploy tiap kali lo push ke GitHub

> Setelah deploy pertama kali, jalanin `npm run deploy` sekali (bisa lewat Railway shell/CLI atau lokal) buat daftarin slash command ke server.

## 📋 Daftar Command

| Command | Fungsi | Permission |
|---|---|---|
| `/ban` | Ban member | Ban Members |
| `/kick` | Kick member | Kick Members |
| `/mute` | Timeout member | Moderate Members |
| `/warn` | Kasih warning (auto-mute/kick/ban di threshold 3/5/7) | Moderate Members |
| `/warnings` | Lihat riwayat warning member | Moderate Members |
| `/automod` | Toggle nyala/mati fitur automod | Manage Guild |
| `/newscript` | Post notifikasi script baru | **Owner only** |

## 🛡️ Automod
Otomatis jalan tiap ada pesan masuk:
- **Anti-spam**: >5 pesan dalam 5 detik → auto-mute 5 menit
- **Anti-link**: hapus link selain domain whitelist (github.com, mediafire.com, discord.gg, dll — edit di `data/automod-config.json`)
- **Filter kata kasar**: auto-delete + auto-warn

Semua konfigurasi automod (kata yang difilter, whitelist domain, threshold) bisa diedit langsung di `data/automod-config.json`.

## 📂 Struktur
```
commands/
  moderation/  → ban, kick, mute, warn, warnings
  automod/     → toggle automod
  notify/      → newscript (owner-only)
events/        → ready, interactionCreate, messageCreate
utils/         → storage, warnHandler, automod
data/          → warns.json, automod-config.json (auto-update saat bot jalan)
```
