const { readJSON } = require('./storage');
const { EmbedBuilder } = require('discord.js');

async function applyWarnConsequence(guild, member, warnCount) {
  const config = readJSON('automod-config.json');
  const { muteAt, kickAt, banAt } = config.warnThreshold;

  try {
    if (warnCount === banAt && member.bannable) {
      await member.ban({ reason: `Auto-ban: mencapai ${banAt} warning` });
      await logAction(guild, `🔨 ${member.user.tag} auto-ban (${banAt} warning)`);
    } else if (warnCount === kickAt && member.kickable) {
      await member.kick(`Auto-kick: mencapai ${kickAt} warning`);
      await logAction(guild, `👢 ${member.user.tag} auto-kick (${kickAt} warning)`);
    } else if (warnCount === muteAt && member.moderatable) {
      await member.timeout(10 * 60 * 1000, `Auto-mute: mencapai ${muteAt} warning`);
      await logAction(guild, `🔇 ${member.user.tag} auto-mute 10 menit (${muteAt} warning)`);
    }
  } catch (err) {
    console.error('Gagal apply warn consequence:', err.message);
  }
}

async function logAction(guild, message) {
  const logChannelId = process.env.LOG_CHANNEL_ID;
  if (!logChannelId) return;

  const channel = guild.channels.cache.get(logChannelId);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(0x2F3136)
    .setDescription(message)
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { applyWarnConsequence, logAction };
