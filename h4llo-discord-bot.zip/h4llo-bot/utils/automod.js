const { readJSON, writeJSON } = require('./storage');
const { logAction, applyWarnConsequence } = require('./warnHandler');

// Simpan history pesan tiap user di memory (buat cek spam) - reset kalau bot restart
const messageHistory = new Map();

async function handleAutomod(message) {
  if (message.author.bot) return;
  if (!message.guild) return;
  if (message.member?.permissions.has('ManageMessages')) return; // skip moderator

  const config = readJSON('automod-config.json');

  // 1. Anti-spam
  if (config.antiSpam.enabled) {
    const isSpam = checkSpam(message, config.antiSpam);
    if (isSpam) {
      await message.member.timeout(
        config.antiSpam.muteMinutes * 60 * 1000,
        'Automod: terdeteksi spam'
      ).catch(() => {});
      await message.channel.send(
        `⚠️ ${message.author}, lo di-mute ${config.antiSpam.muteMinutes} menit karena spam.`
      ).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      await logAction(message.guild, `🔇 ${message.author.tag} auto-mute karena spam`);
      await bulkDeleteRecent(message);
      return;
    }
  }

  // 2. Anti-link
  if (config.antiLink.enabled && containsUnwantedLink(message.content, config.antiLink.whitelist)) {
    await message.delete().catch(() => {});
    await message.channel.send(
      `🔗 ${message.author}, link gak diizinkan (kecuali dari domain whitelist).`
    ).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
    await logAction(message.guild, `🔗 Pesan ${message.author.tag} dihapus (link tidak diizinkan)`);
    return;
  }

  // 3. Filter kata kasar
  if (config.badWords.enabled && containsBadWord(message.content, config.badWords.words)) {
    await message.delete().catch(() => {});
    await message.channel.send(
      `🤬 ${message.author}, tolong jaga bahasa ya.`
    ).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
    await logAction(message.guild, `🤬 Pesan ${message.author.tag} dihapus (kata kasar)`);

    // Auto-warn
    const warns = readJSON('warns.json');
    if (!warns[message.author.id]) warns[message.author.id] = [];
    warns[message.author.id].push({
      reason: 'Automod: kata kasar',
      moderator: 'Automod',
      timestamp: Date.now(),
    });
    writeJSON('warns.json', warns);
    await applyWarnConsequence(message.guild, message.member, warns[message.author.id].length);
    return;
  }
}

function checkSpam(message, spamConfig) {
  const userId = message.author.id;
  const now = Date.now();

  if (!messageHistory.has(userId)) {
    messageHistory.set(userId, []);
  }

  const history = messageHistory.get(userId).filter(
    ts => now - ts < spamConfig.timeWindowMs
  );
  history.push(now);
  messageHistory.set(userId, history);

  return history.length > spamConfig.maxMessages;
}

async function bulkDeleteRecent(message) {
  try {
    const messages = await message.channel.messages.fetch({ limit: 10 });
    const userMessages = messages.filter(
      m => m.author.id === message.author.id && Date.now() - m.createdTimestamp < 6000
    );
    await message.channel.bulkDelete(userMessages).catch(() => {});
  } catch (err) {
    console.error('Gagal bulk delete:', err.message);
  }
}

function containsUnwantedLink(content, whitelist) {
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  const urls = content.match(urlRegex);
  if (!urls) return false;

  return urls.some(url => {
    return !whitelist.some(domain => url.includes(domain));
  });
}

function containsBadWord(content, badWords) {
  const lower = content.toLowerCase();
  return badWords.some(word => {
    const regex = new RegExp(`\\b${word}\\b`, 'i');
    return regex.test(lower);
  });
}

module.exports = { handleAutomod };
