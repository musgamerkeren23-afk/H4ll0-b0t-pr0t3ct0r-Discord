const fs = require('fs');
const path = require('path');

function readJSON(filename) {
  const filePath = path.join(__dirname, '..', 'data', filename);
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Gagal baca ${filename}:`, err.message);
    return {};
  }
}

function writeJSON(filename, data) {
  const filePath = path.join(__dirname, '..', 'data', filename);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error(`Gagal tulis ${filename}:`, err.message);
    return false;
  }
}

module.exports = { readJSON, writeJSON };
