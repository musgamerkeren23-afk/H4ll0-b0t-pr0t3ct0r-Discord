const { handleAutomod } = require('../utils/automod');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    await handleAutomod(message);
  },
};
