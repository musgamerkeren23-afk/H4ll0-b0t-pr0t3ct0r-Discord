module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ Bot online sebagai ${client.user.tag}`);
    client.user.setActivity('H4ll0 W0rld 🔥', { type: 3 }); // type 3 = Watching
  },
};
