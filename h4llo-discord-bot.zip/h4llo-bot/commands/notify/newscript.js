const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('newscript')
    .setDescription('[OWNER ONLY] Post notifikasi script baru H4ll0 W0rld')
    .addStringOption(opt =>
      opt.setName('nama').setDescription('Nama script').setRequired(true))
    .addStringOption(opt =>
      opt.setName('link').setDescription('Link download (GitHub/MediaFire)').setRequired(true))
    .addStringOption(opt =>
      opt.setName('deskripsi').setDescription('Deskripsi singkat script').setRequired(false))
    .addStringOption(opt =>
      opt.setName('gambar').setDescription('URL screenshot/thumbnail').setRequired(false)),

  async execute(interaction) {
    // Owner-only check
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: '❌ Command ini cuma bisa dipakai owner H4ll0 W0rld.',
        ephemeral: true,
      });
    }

    const nama = interaction.options.getString('nama');
    const link = interaction.options.getString('link');
    const deskripsi = interaction.options.getString('deskripsi') || 'Script baru udah rilis!';
    const gambar = interaction.options.getString('gambar');

    const targetChannelId = process.env.SCRIPT_CHANNEL_ID;
    const channel = targetChannelId
      ? interaction.guild.channels.cache.get(targetChannelId)
      : interaction.channel;

    if (!channel) {
      return interaction.reply({ content: '❌ Channel notifikasi gak ketemu. Cek SCRIPT_CHANNEL_ID di .env', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle(`🆕 Script Baru: ${nama}`)
      .setDescription(deskripsi)
      .addFields({ name: '📥 Download', value: link })
      .setFooter({ text: 'H4ll0 W0rld' })
      .setTimestamp();

    if (gambar) embed.setImage(gambar);

    await channel.send({ content: '@everyone', embeds: [embed] });
    await interaction.reply({ content: `✅ Notifikasi script "${nama}" udah diposting ke <#${channel.id}>`, ephemeral: true });
  },
};
