const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { readJSON, writeJSON } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Nyalain/matiin fitur automod')
    .addStringOption(opt =>
      opt.setName('fitur')
        .setDescription('Fitur automod yang mau diatur')
        .setRequired(true)
        .addChoices(
          { name: 'Anti-Spam', value: 'antiSpam' },
          { name: 'Anti-Link', value: 'antiLink' },
          { name: 'Filter Kata Kasar', value: 'badWords' }
        ))
    .addStringOption(opt =>
      opt.setName('status')
        .setDescription('Nyalain atau matiin')
        .setRequired(true)
        .addChoices(
          { name: 'Nyala', value: 'on' },
          { name: 'Mati', value: 'off' }
        ))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const fitur = interaction.options.getString('fitur');
    const status = interaction.options.getString('status') === 'on';

    const config = readJSON('automod-config.json');
    config[fitur].enabled = status;
    writeJSON('automod-config.json', config);

    const embed = new EmbedBuilder()
      .setColor(status ? 0x00FF00 : 0xFF0000)
      .setDescription(`✅ **${fitur}** sekarang **${status ? 'NYALA' : 'MATI'}**`);

    await interaction.reply({ embeds: [embed] });
  },
};
