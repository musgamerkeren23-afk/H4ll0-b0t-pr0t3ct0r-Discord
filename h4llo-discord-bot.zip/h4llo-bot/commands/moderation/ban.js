const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban member dari server')
    .addUserOption(opt =>
      opt.setName('target').setDescription('User yang mau di-ban').setRequired(true))
    .addStringOption(opt =>
      opt.setName('alasan').setDescription('Alasan ban').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('alasan') || 'Tidak ada alasan';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '❌ User itu gak ada di server ini.', ephemeral: true });
    }
    if (!member.bannable) {
      return interaction.reply({ content: '❌ Gue gak bisa ban user ini (role dia lebih tinggi / owner).', ephemeral: true });
    }

    await member.ban({ reason });

    const embed = new EmbedBuilder()
      .setColor(0x8B0000)
      .setTitle('🔨 Member di-ban')
      .addFields(
        { name: 'User', value: `${target.tag} (${target.id})` },
        { name: 'Alasan', value: reason },
        { name: 'Moderator', value: interaction.user.tag }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
