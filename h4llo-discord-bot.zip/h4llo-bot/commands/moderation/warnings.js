const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { readJSON } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Lihat riwayat warning member')
    .addUserOption(opt =>
      opt.setName('target').setDescription('User yang mau dicek').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const warns = readJSON('warns.json');
    const userWarns = warns[target.id] || [];

    if (userWarns.length === 0) {
      return interaction.reply({ content: `✅ ${target.tag} belum pernah kena warning.`, ephemeral: true });
    }

    const list = userWarns
      .map((w, i) => `**${i + 1}.** ${w.reason} — oleh *${w.moderator}* (<t:${Math.floor(w.timestamp / 1000)}:R>)`)
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle(`⚠️ Riwayat Warning: ${target.tag}`)
      .setDescription(list)
      .setFooter({ text: `Total: ${userWarns.length} warning` });

    await interaction.reply({ embeds: [embed] });
  },
};
