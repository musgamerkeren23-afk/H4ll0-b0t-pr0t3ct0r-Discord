const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick member dari server')
    .addUserOption(opt =>
      opt.setName('target').setDescription('User yang mau di-kick').setRequired(true))
    .addStringOption(opt =>
      opt.setName('alasan').setDescription('Alasan kick').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('alasan') || 'Tidak ada alasan';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '❌ User itu gak ada di server ini.', ephemeral: true });
    }
    if (!member.kickable) {
      return interaction.reply({ content: '❌ Gue gak bisa kick user ini (role dia lebih tinggi / owner).', ephemeral: true });
    }

    await member.kick(reason);

    const embed = new EmbedBuilder()
      .setColor(0xFF8C00)
      .setTitle('👢 Member di-kick')
      .addFields(
        { name: 'User', value: `${target.tag} (${target.id})` },
        { name: 'Alasan', value: reason },
        { name: 'Moderator', value: interaction.user.tag }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
