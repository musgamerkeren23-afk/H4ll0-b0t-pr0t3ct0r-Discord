const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute (timeout) member untuk durasi tertentu')
    .addUserOption(opt =>
      opt.setName('target').setDescription('User yang mau di-mute').setRequired(true))
    .addIntegerOption(opt =>
      opt.setName('menit').setDescription('Durasi mute dalam menit').setRequired(true))
    .addStringOption(opt =>
      opt.setName('alasan').setDescription('Alasan mute').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const minutes = interaction.options.getInteger('menit');
    const reason = interaction.options.getString('alasan') || 'Tidak ada alasan';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '❌ User itu gak ada di server ini.', ephemeral: true });
    }
    if (!member.moderatable) {
      return interaction.reply({ content: '❌ Gue gak bisa mute user ini.', ephemeral: true });
    }
    if (minutes < 1 || minutes > 40320) {
      return interaction.reply({ content: '❌ Durasi harus antara 1 menit - 28 hari.', ephemeral: true });
    }

    await member.timeout(minutes * 60 * 1000, reason);

    const embed = new EmbedBuilder()
      .setColor(0x808080)
      .setTitle('🔇 Member di-mute')
      .addFields(
        { name: 'User', value: `${target.tag} (${target.id})` },
        { name: 'Durasi', value: `${minutes} menit` },
        { name: 'Alasan', value: reason },
        { name: 'Moderator', value: interaction.user.tag }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
