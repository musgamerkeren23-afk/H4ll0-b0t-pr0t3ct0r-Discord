const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { readJSON, writeJSON } = require('../../utils/storage');
const { applyWarnConsequence } = require('../../utils/warnHandler');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Kasih warning ke member')
    .addUserOption(opt =>
      opt.setName('target').setDescription('User yang mau di-warn').setRequired(true))
    .addStringOption(opt =>
      opt.setName('alasan').setDescription('Alasan warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('alasan');
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '❌ User itu gak ada di server ini.', ephemeral: true });
    }

    const warns = readJSON('warns.json');
    if (!warns[target.id]) warns[target.id] = [];
    warns[target.id].push({
      reason,
      moderator: interaction.user.tag,
      timestamp: Date.now(),
    });
    writeJSON('warns.json', warns);

    const warnCount = warns[target.id].length;

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('⚠️ Member di-warn')
      .addFields(
        { name: 'User', value: `${target.tag} (${target.id})` },
        { name: 'Alasan', value: reason },
        { name: 'Total Warn', value: `${warnCount}` },
        { name: 'Moderator', value: interaction.user.tag }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    // Cek threshold otomatis (mute/kick/ban)
    await applyWarnConsequence(interaction.guild, member, warnCount);
  },
};
